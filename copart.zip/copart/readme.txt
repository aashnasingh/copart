The given problem's solution is developed using JSP and Servlet, as I was travelling and there was a time crunch so I could not implement the 
use cases. Though I have a proper understanding of how everything was to be implemented.

I made two registrations servlets, indiviual.java(for individual registration) and team.java(for team registrations) that store data to the same
table named "teamlogin". The tables columns are userid, password, teamname, first individual's name, second individual's name, 
third individual's name. For individual userid, password and first individual's name are filled. For team, userid, password, teamname, first individual's name, second individual's name, 
third individual's name are filled, but third individual's name can be left null and also there cannot be less than two names in a team.

The loginauth, and both the registration servlets redirect to subm.jsp where a submission can be uploaded and a language has to be specified. 
The page also contains logout and deregister buttons. The second table "submissions" contain submissionid, first submission file, second submission file,
third submission file, a submission counter, first language, second language. I could not implement but the logic for this goes, 
submission servlet would accept the file, language and the userid in the session(which gets stored in this table as submissionid).
 A select query runs for the particular userid, and retrieves value of the submission counter(whose default is zero) and the first language and 
 second language fields. Next, by multiple if-else statements determining the counter value and whether the language fields are null or what language
 has been used, update query is executed. If the submission counter is zero for the particular id, insert query is executed. Logout simply logs out of the session and redirects to login page.
 
 