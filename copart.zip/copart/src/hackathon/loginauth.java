package hackathon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class loginauth
 */
@WebServlet("/loginauth")
public class loginauth extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginauth() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            HttpSession session=request.getSession();
            String userName = request.getParameter("userid");
  		  String pass = request.getParameter("password");
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/copart", "root", "aashna");
            

            PreparedStatement pst=con.prepareStatement("select * from login where id=? and password=?");
            pst.setString(1, userName);
            pst.setString(2, pass);
            ResultSet rs=pst.executeQuery();
            if(rs.next())
            {
                session.setAttribute("username", userName);
              RequestDispatcher rd=request.getRequestDispatcher("subm.jsp");
              rd.forward(request, response);
              
            }
            else
            {
              RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
              out.println("<font color=red>Username or Password incorrect</font>");
              rd.forward(request, response);
            }
        } 
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally {
            out.close();
        }
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

}
