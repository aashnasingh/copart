package hackathon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class team - Team Registration
 */
@WebServlet("/team")
public class team extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public team() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		  PrintWriter out = response.getWriter();
		  String teamnm = request.getParameter("teamname");
		  String userName = request.getParameter("userid");
		  String pass = request.getParameter("password");
		  String frst = request.getParameter("firstindi");
		  String sec = request.getParameter("secondindi");
		  String third = request.getParameter("thirdindi");

		  // validate given input
		  if (teamnm.isEmpty() || userName.isEmpty() || pass.isEmpty() || frst.isEmpty() || sec.isEmpty()) {
		   RequestDispatcher rd = request.getRequestDispatcher("teamreg.jsp");
		   out.println("<font color=red>Please fill all the fields. A team cannot have less than two members or more than three members.</font>");
		   rd.include(request, response);
		  } else {
		   
		   try {
		    Class.forName("com.mysql.jdbc.Driver");

		    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/copart", "root", "aashna"); 

		    String query = "insert into teamlogin values(?,?,?,?,?,?)";

		    PreparedStatement ps = con.prepareStatement(query); // generates sql query

		    ps.setString(1, userName);
		    ps.setString(2, pass);
		    ps.setString(3, teamnm);
		    ps.setString(4, frst);
		    ps.setString(5, sec);
		    ps.setString(6, third);
		    

		    ps.executeUpdate(); // execute it on test database
		    System.out.println("successfuly inserted");
		    ps.close();
		    con.close();
		   } catch (ClassNotFoundException | SQLException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		   }
		   RequestDispatcher rd = request.getRequestDispatcher("subm.jsp");
		   rd.forward(request, response);
		  }
	}

}
