<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Submission</title>
</head>
<style>
div.ex {
	text-align: right width:300px;
	padding: 10px;
	border: 5px solid grey;
	margin: 0px
}
</style>
<body>
	<h1>Registration Form</h1>
	<div class="ex">
		<form action="team" method="post">
			<table style="with: 50%">
				<tr>
					<td>Team Name</td>
					<td><input type="text" name="teamname" /></td>
				</tr>
				<tr>
					<td>Username</td>
					<td><input type="text" name="userid" /></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="password" /></td>
				</tr>
				<tr>
					<td>First Participant Name</td>
					<td><input type="text" name="firstindi" /></td>
				</tr>
				<tr>
					<td>Second Participant Name</td>
					<td><input type="text" name="secondindi" /></td>
				</tr>
				<tr>
					<td>Third Participant Name</td>
					<td><input type="text" name="thirdindi" /></td>
				</tr>
			</table>
			<input type="submit" value="Register" />
		</form>
		<br>
	
		
		
		
	</div>
</body>
</html>