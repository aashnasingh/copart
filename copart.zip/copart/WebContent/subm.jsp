<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Submission Page</title>
</head>
<style>
div.ex {
	text-align: right width:300px;
	padding: 10px;
	border: 5px solid grey;
	margin: 0px
}
div.logoutLblPos{

   position:fixed;
   right:10px;
   top:5px;
}
</style>
<body>
<div class="ex">

	<fieldset>
	
        <legend>Upload File</legend>
        <form action="submiss" method="post" enctype="multipart/form-data">
            <label for="filename_1">File: </label>
            <input id="filename_1" type="file" name="filename_1" size="50"/><br/>
            <br/>
            <select name="lang">
    <option value="python">Python</option>
    <option value="java">Java</option>
    <option value="php">PHP</option>
    <option value="csharp">C#</option>
  </select>
            <input type="submit" value="Upload File"/>
        </form>
    </fieldset>
    </div>
    <div class = "logoutLblPos">
    <form align="right" method="post" action="login.jsp">
  <label class="logoutLblPos">
  <input name="submit2" type="submit" id="submit2" value="log out">
  </label>
  
</form>
<form align="right" method="post" action="dereg">
  <label class="logoutLblPos">
  <input name="submit3" type="submit" id="submit3" value="Deregister">
  </label>
  
</form>
    </div>
    
</body>
</html>