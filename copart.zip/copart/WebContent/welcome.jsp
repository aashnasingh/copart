<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Welcome</title>
</head>
<body>
	<h1>Welcome to Hackathon.</h1><br>
    <a href="indireg.jsp">Individual Registration</a><br>
    <a href="teamreg.jsp">Team Registration</a><br>
    <a href="login.jsp">Login</a>
</body>
</html>